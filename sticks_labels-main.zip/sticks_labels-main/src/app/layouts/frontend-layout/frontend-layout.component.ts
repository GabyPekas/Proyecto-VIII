import { Component } from "@angular/core";


@Component({
  selector: 'app-frontend-layout',
  templateUrl: './frontend-layout.component.html'
})
export class FrontEndLayoutComponent  {


}
