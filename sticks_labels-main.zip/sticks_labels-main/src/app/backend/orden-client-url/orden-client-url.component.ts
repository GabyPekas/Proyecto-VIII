import { Component } from '@angular/core';

@Component({
  selector: 'app-orden-client-url',
  templateUrl: './orden-client-url.component.html'
})
export class OrdenClientUrlComponent {

}
