import { Component } from '@angular/core';

@Component({
  selector: 'app-orden-asesor-url',
  templateUrl: './orden-asesor-url.component.html'
})
export class OrdenAsesorUrlComponent {

}
