import { Component } from '@angular/core';

@Component({
  selector: 'app-ordenes-cliente',
  templateUrl: './ordenes-cliente.component.html'
})
export class OrdenesClienteComponent {

}
